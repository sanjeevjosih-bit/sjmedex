import axios from 'axios';

const api = axios.create({
  baseURL: '/api',
});

// Attach token to every request if present
api.interceptors.request.use(config => {
  const token = localStorage.getItem('sjmedex_token');
  if (token) config.headers.Authorization = `Bearer ${token}`;
  return config;
});

// Auto-logout on 401
api.interceptors.response.use(
  res => res,
  err => {
    if (err.response?.status === 401) {
      localStorage.removeItem('sjmedex_token');
      localStorage.removeItem('sjmedex_user');
      window.location.href = '/login';
    }
    return Promise.reject(err);
  }
);

export default api;
